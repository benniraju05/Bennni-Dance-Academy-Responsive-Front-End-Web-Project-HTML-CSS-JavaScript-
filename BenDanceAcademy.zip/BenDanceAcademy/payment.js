// Import Firebase SDKs
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import { getDatabase, ref, push } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-database.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDGcTejA6mfsqbjotTDl1-5G4meF1f_pXk",
  authDomain: "payment-24753.firebaseapp.com",
  databaseURL: "https://payment-24753-default-rtdb.firebaseio.com",
  projectId: "payment-24753",
  storageBucket: "payment-24753.firebasestorage.app",
  messagingSenderId: "192512330656",
  appId: "1:192512330656:web:1cbcc8fe3540155234f2c5"
};


// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

// Define `cancelTransaction` globally
window.cancelTransaction = function () {
  alert("Transaction has been cancelled. Redirecting to the home page...");
  window.location.assign("home.html"); // Redirect to home.html
};

// Real-time input restrictions for numeric fields
window.validateAmountInput = function (input) {
  input.value = input.value.replace(/\D/g, ""); // Allow only digits
};

window.formatCardNumber = function (input) {
  let value = input.value.replace(/\D/g, ""); // Remove non-numeric characters
  if (value.length > 16) {
    value = value.slice(0, 16); // Limit to 16 digits
  }
  input.value = value.match(/.{1,4}/g)?.join("-") || value; // Format in groups of 4
};

window.validateExpDate = function (input) {
  input.value = input.value.replace(/[^0-9\/]/g, ""); // Allow only numbers and slash
  if (input.value.length > 2 && !input.value.includes("/")) {
    input.value = input.value.slice(0, 2) + "/" + input.value.slice(2); // Format as MM/YYYY
  }
  input.value = input.value.slice(0, 7); // Limit to MM/YYYY
};

// Real-time input restrictions for CVV field
window.validateCVV = function (input) {
  input.value = input.value.replace(/\D/g, "").slice(0, 4); // Allow only digits and limit to 4 characters
};

// Function to validate student details
function validateStudentDetails() {
  const studentFields = [
    document.getElementById("goals"), // Student ID
    document.getElementById("firstname"), // First Name
    document.getElementById("lastname"), // Last Name
    document.getElementById("email"), // Email
    document.getElementById("phone"), // Phone Number
  ];

  for (const field of studentFields) {
    if (!field.value.trim()) {
      alert(`Please fill out the ${field.placeholder || field.id} field.`);
      field.focus();
      return false;
    }
  }

  // Email validation
  const email = document.getElementById("email").value.trim();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    alert("Please enter a valid email address.");
    document.getElementById("email").focus();
    return false;
  }

  // Phone validation (10-15 digits)
  const phone = document.getElementById("phone").value.trim();
  const phoneRegex = /^\d{10,15}$/;
  if (!phoneRegex.test(phone)) {
    alert("Please enter a valid phone number (10-15 digits).");
    document.getElementById("phone").focus();
    return false;
  }

  return true; // All student details are valid
}

// Function to validate payment details
function validatePaymentDetails(paymentType) {
  const paymentFields =
    paymentType === "debit"
      ? [
          document.getElementById("debitAmount"),
          document.getElementById("cardNumber"),
          document.getElementById("expDate"),
          document.getElementById("cvv"),
          document.getElementById("name"),
        ]
      : [
          document.getElementById("creditAmount"),
          document.getElementById("creditCardNumber"),
          document.getElementById("creditExpDate"),
          document.getElementById("creditCvv"),
          document.getElementById("creditCardHolderName"),
        ];

  for (const field of paymentFields) {
    if (!field.value.trim()) {
      alert(`Please fill out the ${field.placeholder || field.id} field.`);
      field.focus();
      return false;
    }
  }

  // Additional validations
  const expDate = paymentType === "debit"
    ? document.getElementById("expDate").value.trim()
    : document.getElementById("creditExpDate").value.trim();

  const parts = expDate.split("/");
  if (parts.length === 2 && parts[1].length === 4) {
    const currentYear = new Date().getFullYear();
    const month = parseInt(parts[0], 10);
    const year = parseInt(parts[1], 10);

    if (isNaN(month) || month < 1 || month > 12) {
      alert("Please enter a valid month (01-12).");
      return false;
    }
    if (isNaN(year) || year < currentYear) {
      alert("Expiration year must be in the future.");
      return false;
    }
  } else {
    alert("Please enter the expiration date in MM/YYYY format.");
    return false;
  }

  return true; // All payment details are valid
}

// Function to generate a random transaction number
function generateTransactionNumber() {
  const timestamp = Date.now().toString(); // Current timestamp
  const randomChars = Math.random().toString(36).substring(2, 10); // Random alphanumeric string
  return `TXN-${timestamp}-${randomChars}`; // Combine for a unique transaction ID
}

// Function to generate a PDF Invoice
function generatePDFInvoice(studentDetails, paymentDetails, transactionNumber) {
  const { jsPDF } = window.jspdf; // Access jsPDF
  const doc = new jsPDF();

  // Header
  doc.setFontSize(16);
  doc.text("Ben Dance Academy", 105, 20, { align: "center" });
  doc.setFontSize(12);
  doc.text("Invoice", 105, 30, { align: "center" });

  // Student Details Section
  doc.setFontSize(14);
  doc.text("Student Details:", 10, 50);
  doc.setFontSize(12);
  doc.text(`Student ID: ${studentDetails.studentId}`, 10, 60);
  doc.text(`First Name: ${studentDetails.firstName}`, 10, 70);
  doc.text(`Last Name: ${studentDetails.lastName}`, 10, 80);
  doc.text(`Email: ${studentDetails.email}`, 10, 90);
  doc.text(`Phone Number: ${studentDetails.phone}`, 10, 100);

  // Transaction Details Section
  doc.setFontSize(14);
  doc.text("Transaction Details:", 10, 120);
  doc.setFontSize(12);
  doc.text(`Selected Service / Paid For: ${paymentDetails.selectedService}`, 10, 130);
  doc.text(`Amount Paid: $${paymentDetails.amount}`, 10, 140);
  doc.text(`Payment Date: ${new Date().toLocaleString()}`, 10, 150);
  doc.text(`Payment Type: ${paymentDetails.paymentType}`, 10, 160);
  doc.text(`Card Holder Name: ${paymentDetails.cardHolderName}`, 10, 170);
  doc.text(`Transaction Number: ${transactionNumber}`, 10, 180);

  // Note
  doc.setFontSize(10);
  doc.setTextColor(150);
  doc.text(
    "Note: Please keep this invoice safe for future references.",
    10,
    200
  );

  // Save the PDF
  doc.save(`Invoice_${transactionNumber}.pdf`);
}

// Function to store data in Firebase
function storeDataInFirebase(paymentType) {
  const transactionNumber = generateTransactionNumber(); // Generate a unique transaction number
  // Get the value of the selected dropdown option
  const selectedService =
    paymentType === "debit"
      ? document.getElementById("debitService").value.trim()
      : document.getElementById("creditService").value.trim();
  const studentDetails = {
    studentId: document.getElementById("goals").value.trim(),
    firstName: document.getElementById("firstname").value.trim(),
    lastName: document.getElementById("lastname").value.trim(),
    email: document.getElementById("email").value.trim(),
    phone: document.getElementById("phone").value.trim(),
  };

  const paymentDetails =
    paymentType === "debit"
      ? {
          paymentType: "Debit Card",
          selectedService, // Add the selected service to the stored data
          amount: document.getElementById("debitAmount").value.trim(),
          cardNumber: document.getElementById("cardNumber").value.trim(),
          expDate: document.getElementById("expDate").value.trim(),
          cvv: document.getElementById("cvv").value.trim(),
          cardHolderName: document.getElementById("name").value.trim(),
        }
      : {
          paymentType: "Credit Card",
          selectedService, // Add the selected service to the stored data
          amount: document.getElementById("creditAmount").value.trim(),
          cardNumber: document.getElementById("creditCardNumber").value.trim(),
          expDate: document.getElementById("creditExpDate").value.trim(),
          cvv: document.getElementById("creditCvv").value.trim(),
          cardHolderName: document.getElementById("creditCardHolderName").value.trim(),
        };

        const dataToStore = { ...studentDetails, ...paymentDetails, transactionNumber };

        const paymentsRef = ref(database, "payments");
  push(paymentsRef, dataToStore)
    .then(() => {
      alert(`Payment has been completed successfully! Transaction Number: ${transactionNumber}`);
      generatePDFInvoice(studentDetails, paymentDetails, transactionNumber); // Generate PDF
    })
    .catch((error) => {
      console.error("Error saving payment data:", error);
      alert("Failed to save payment data. Please try again.");
    });
}

// Attach event listeners
function attachEventListeners() {
  document.getElementById("debitCardButton").addEventListener("click", () => showPaymentForm("debit"));
  document.getElementById("creditCardButton").addEventListener("click", () => showPaymentForm("credit"));

  document.getElementById("completePaymentButton").addEventListener("click", (e) => {
    e.preventDefault();
    if (validateStudentDetails() && validatePaymentDetails("debit")) {
      storeDataInFirebase("debit");
    }
  });

  document.getElementById("creditCompletePaymentButton").addEventListener("click", (e) => {
    e.preventDefault();
    if (validateStudentDetails() && validatePaymentDetails("credit")) {
      storeDataInFirebase("credit");
    }
  });
  // Real-time validation for CVV fields
  document.getElementById("cvv").addEventListener("input", (e) => validateCVV(e.target));
  document.getElementById("creditCvv").addEventListener("input", (e) => validateCVV(e.target));
}

// Function to show the selected payment form
function showPaymentForm(paymentType) {
  const forms = document.getElementsByClassName("payment-form-details");
  for (let i = 0; i < forms.length; i++) forms[i].style.display = "none";
  document.getElementById(paymentType === "debit" ? "debit-details" : "credit-details").style.display = "block";
}

// Attach event listeners on DOM load
document.addEventListener("DOMContentLoaded", () => attachEventListeners());