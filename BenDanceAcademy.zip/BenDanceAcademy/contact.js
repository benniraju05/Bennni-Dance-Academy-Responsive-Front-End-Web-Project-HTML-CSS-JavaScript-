 // Your web app's Firebase configuration
 const firebaseConfig = {
  apiKey: "AIzaSyBorjLpb0Joyzxz2oTJqRQ9WkVEaLwbem4",
  authDomain: "bendance-63612.firebaseapp.com",
  databaseURL: "https://bendance-63612-default-rtdb.firebaseio.com",
  projectId: "bendance-63612",
  storageBucket: "bendance-63612.firebasestorage.app",
  messagingSenderId: "755717175031",
  appId: "1:755717175031:web:bd17238ecb5de8a25c85f2"
};

  
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
  
// Reference for the database
var contactusFormDB = firebase.database().ref("contactusForm");
  
// Form submission event listener
document.getElementById("contactusForm").addEventListener("submit", submitForm);
  
function submitForm(e) {
  e.preventDefault();

  var name = getElementVal("name");
  var emailid = getElementVal("emailid");
  var mobile = getElementVal("mobile");
  var msgContent = getElementVal("msgContent");

  // Validate the form
  if (validateForm(name, emailid, mobile, msgContent)) {
    saveMessages(name, emailid, mobile, msgContent);

    // Display confirmation message
    alert("Thank you for submitting your details. One of our representatives will contact you back within 24hrs...");

    // Redirect to home.html after 3 seconds
    setTimeout(() => {
      window.location.href = "home.html";
    }, 3000);

    // Form reset after message is stored
    document.getElementById("contactusForm").reset();
  }
}
  
const saveMessages = (name, emailid, mobile, msgContent) => {
  var newcontactusForm = contactusFormDB.push();
  newcontactusForm.set({
    name: name,
    emailid: emailid,
    mobile: mobile,
    msgContent: msgContent,
  });
};
  
// Get form values
const getElementVal = (id) => {
  return document.getElementById(id).value;
};
  
// Validate the form
const validateForm = (name, emailid, mobile, msgContent) => {
  if (name === "" || emailid === "" || mobile === "" || msgContent === "") {
    alert("All fields are required. Please fill out Your Name, Your Email, Phone number, and Your Message / Query.");
    return false;
  }
  if (!validateEmail(emailid)) {
    alert("Please enter a valid email address.");
    return false;
  }
  if (!validateMobile(mobile)) {
    alert("Please enter a valid 10-digit mobile number.");
    return false;
  }
  return true;
};
  
// Validate email format
const validateEmail = (email) => {
  const re = /^(([^<>()\[\]\.,;:\s@"]+(\.[^<>()\[\]\.,;:\s@"]+)*)|(".+"))@(([^<>()[\]\.,;:\s@"]+\.)+[^<>()[\]\.,;:\s@"]{2,})$/i;
  return re.test(String(email).toLowerCase());
};
  
// Validate mobile format
const validateMobile = (mobile) => {
  const re = /^\d{10}$/;
  return re.test(String(mobile));
};