// Event handler for payment method buttons
function handlePaymentButtonClick(e) {
    e.preventDefault(); // Prevent default button behavior
    const paymentType = e.target.textContent.toLowerCase().includes('debit') ? 'debit' : 'credit';
    showPaymentForm(paymentType);
}

// Attach event listeners for "Credit Card" and "Debit Card" buttons
document.querySelectorAll('.payment-methods button').forEach(button => {
    button.removeEventListener('click', handlePaymentButtonClick); // Ensure no duplicate listeners
    button.addEventListener('click', handlePaymentButtonClick); // Add fresh listener
});

function showPaymentForm(paymentType) {
    // Validate student details only once
    if (!validateStudentDetails()) {
        return; // Stop execution if validation fails
    }

    // Hide all forms
    const forms = document.getElementsByClassName('payment-form-details');
    for (let i = 0; i < forms.length; i++) {
        forms[i].style.display = 'none';
    }

    // Show the selected payment form
    const detailId = paymentType + '-details';
    document.getElementById(detailId).style.display = 'block';
}

// Function to validate student details
function validateStudentDetails() {
    const studentId = document.getElementById('goals').value.trim();
    const firstName = document.getElementById('firstname').value.trim();
    const lastName = document.getElementById('lastname').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();

    if (!studentId || !firstName || !lastName || !email || !phone) {
        alert('Please fill your student details to make payment. If you forgot your student ID, please contact the office.');
        return false;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Please enter a valid email address.');
        return false;
    }

    const phoneRegex = /^\d{10,15}$/;
    if (!phoneRegex.test(phone)) {
        alert('Please enter a valid phone number (10-15 digits).');
        return false;
    }

    return true;
}


// Function to reset the form fields
function resetForm() {
    const formElements = document.querySelectorAll('input, select');
    formElements.forEach(element => {
        if (element.type === 'text' || element.type === 'email' || element.type === 'tel' || element.tagName === 'SELECT') {
            element.value = ''; // Clear the value
        }
    });
}

function validatePaymentForm(paymentType) {
    const cardNumber = paymentType === 'debit'
        ? document.getElementById('cardNumber').value.replace(/-/g, '')
        : document.getElementById('creditCardNumber').value.replace(/-/g, '');
    const expDate = paymentType === 'debit'
        ? document.getElementById('expDate').value
        : document.getElementById('creditExpDate').value;
    const cvv = paymentType === 'debit'
        ? document.querySelector('input[name="cvv"]').value
        : document.getElementById('creditCvv').value;
    const cardHolderName = paymentType === 'debit'
        ? document.querySelector('input[name="name"]').value.trim()
        : document.getElementById('creditCardHolderName').value.trim();
    const amount = paymentType === 'debit'
        ? document.getElementById('debitAmount').value.trim()
        : document.getElementById('creditAmount').value.trim();

    // Validate form fields
    if (!amount || isNaN(amount) || parseFloat(amount) <= 0) {
        alert('Please enter a valid amount.');
        return false;
    }

    const cardNumberRegex = /^\d{16}$/;
    if (!cardNumberRegex.test(cardNumber)) {
        alert('Card number must be exactly 16 digits.');
        return false;
    }

    const expDateRegex = /^(0[1-9]|1[0-2])\/\d{4}$/;
    if (!expDateRegex.test(expDate)) {
        alert('Expiration date must be in MM/YYYY format.');
        return false;
    }

    const [month, year] = expDate.split('/').map(Number);
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1;
    const currentYear = currentDate.getFullYear();

    if (year < currentYear || (year === currentYear && month < currentMonth)) {
        alert('Expiration date must be a future date.');
        return false;
    }

    const cvvRegex = /^\d{3,4}$/;
    if (!cvvRegex.test(cvv)) {
        alert('CVV must be 3 or 4 numeric digits.');
        return false;
    }

    if (!cardHolderName) {
        alert('Cardholder name is required.');
        return false;
    }

    // Generate transaction number
    const transactionNumber = generateTransactionNumber();

    // Display success message
    alert('Your Transaction Completed Successfully. Transaction number: ' + transactionNumber);

    // Reset the form and redirect
     resetForm();
     setTimeout(() => {
        window.location.assign('home.html');
    }, 500);
}

// Function to generate a random transaction number
function generateTransactionNumber() {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let transactionNumber = '';
    for (let i = 0; i < 8; i++) {
        transactionNumber += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return transactionNumber;
}

// Input restrictions for Amount field
function validateAmountInput(input) {
    input.value = input.value.replace(/\D/g, ''); // Allow only digits
}


// Input restrictions for CVV field
function validateCVVInput(input) {
    input.value = input.value.replace(/\D/g, ''); // Allow only digits
}

// Input formatting for Card Number field
function formatCardNumber(input) {
    let cardNumber = input.value.replace(/\D/g, ''); // Remove non-digit characters

    // Limit to 16 digits
    if (cardNumber.length > 16) {
        cardNumber = cardNumber.slice(0, 16);
    }

    // Format into groups of 4 digits separated by dashes
    if (cardNumber.length > 0) {
        cardNumber = cardNumber.match(/.{1,4}/g).join('-');
    }

    input.value = cardNumber;
}

// Input restrictions for Expiration Date field
function validateExpDate(input) {
    input.value = input.value.replace(/[^0-9\/]/g, ''); // Allow only numbers and slash

    // Automatically add slash after two digits
    if (input.value.length === 2 && !input.value.includes('/')) {
        input.value += '/';
    }

    // Limit to MM/YYYY format
    if (input.value.length > 7) {
        input.value = input.value.slice(0, 7);
    }
}

// Event listeners for Complete Payment buttons
document.getElementById('completePaymentButton').addEventListener('click', function (e) {
    e.preventDefault();
    validatePaymentForm('debit');
});

document.getElementById('creditCompletePaymentButton').addEventListener('click', function (e) {
    e.preventDefault();
    validatePaymentForm('credit');
});

// Attach oninput handlers
document.getElementById('debitAmount').addEventListener('input', function () {
    validateAmountInput(this);
});
document.getElementById('creditAmount').addEventListener('input', function () {
    validateAmountInput(this);
});
document.querySelector('input[name="cvv"]').addEventListener('input', function () {
    validateCVVInput(this);
});
document.getElementById('creditCvv').addEventListener('input', function () {
    validateCVVInput(this);
});




