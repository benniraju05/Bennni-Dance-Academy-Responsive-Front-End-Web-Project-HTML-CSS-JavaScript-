// Import and configure Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-app.js";
import { getDatabase, ref, push, set, get } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-database.js";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBV_9sQJUSRgw0FqnR1UInk02mrwUuigsY",
    authDomain: "register-7d297.firebaseapp.com",
    databaseURL: "https://register-7d297-default-rtdb.firebaseio.com",
    projectId: "register-7d297",
    storageBucket: "register-7d297.firebasestorage.app",
    messagingSenderId: "618089064460",
    appId: "1:618089064460:web:60f0264ffae2112b82e629"
  };


// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

// Add event listener to form submission
document.getElementById("signupForm").addEventListener("submit", (event) => {
    event.preventDefault();
    submitForm();
});

function submitForm() {
    if (validateForm()) {
        saveFormDataToFirebase();
    }
}

function validateForm() {
    let errors = [];

    // Validate First Name
    const firstName = document.getElementById("firstname").value.trim();
    if (!/^[A-Za-z\s]+$/.test(firstName)) {
        errors.push("Name must be Alphabets only.");
    }

    // Validate Last Name
    const lastName = document.getElementById("lastname").value.trim();
    if (!/^[A-Za-z\s]+$/.test(lastName)) {
        errors.push("Name must be Alphabets only.");
    }

    // Validate Email
    const email = document.getElementById("email").value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        errors.push("Please enter a valid email address.");
    }

    // Validate Phone Number
    const phone = document.getElementById("phone").value.trim();
    if (!/^\d{10}$/.test(phone)) {
        errors.push("Phone number must contain exactly 10 digits.");
    }

    // Validate Emergency Contact Number
    const emergencyPhone = document.getElementById("emergencyPhone").value.trim();
    if (!/^\d{10}$/.test(emergencyPhone)) {
        errors.push("Emergency contact number must contain exactly 10 digits.");
    }

    // Validate Date of Birth (Age Check)
    const dob = document.getElementById("dob").value;
    if (!dob) {
        errors.push("Date of Birth is required.");
    } else {
        const selectedDob = new Date(dob);
        const today = new Date();
        const age = today.getFullYear() - selectedDob.getFullYear();
        const isBirthdayPassed = today.getMonth() > selectedDob.getMonth() || 
                                (today.getMonth() === selectedDob.getMonth() && today.getDate() >= selectedDob.getDate());
        if (age < 5 || (age === 5 && !isBirthdayPassed)) {
            errors.push("Age must be at least 5 years old to register in the presence of guardian.");
        }
    }

    // Validate Start Date (should be a future date)
    const startDate = document.getElementById("startDate").value;
    if (new Date(startDate) <= new Date()) {
        errors.push("Start Date must be a future date.");
    }

    // Required select fields
    const requiredFields = ["firstname", "lastname", "email", "phone", "gender", "dob", "address", "emergencyContact", "emergencyPhone", "experience", "paymentPlan", "communication", "hearAboutUs", "lessonType", "preferredTime", "startDate", "duration"];
    requiredFields.forEach((field) => {
        if (!document.getElementById(field).value.trim()) {
            const label = document.querySelector(`label[for="${field}"]`).textContent.replace(":", "");
            errors.push(`${label} is required.`);
        }
    });

    // Display errors if there are any
    if (errors.length > 0) {
        alert("Errors:\n" + errors.join("\n"));
        return false;
    }

    return true;
}

function saveFormDataToFirebase() {
    const formData = {
        firstName: document.getElementById("firstname").value.trim(),
        lastName: document.getElementById("lastname").value.trim(),
        email: document.getElementById("email").value.trim(),
        phone: document.getElementById("phone").value.trim(),
        gender: document.getElementById("gender").value,
        dob: document.getElementById("dob").value,
        address: document.getElementById("address").value.trim(),
        emergencyContact: document.getElementById("emergencyContact").value.trim(),
        emergencyPhone: document.getElementById("emergencyPhone").value.trim(),
        experience: document.getElementById("experience").value,
        goals: document.getElementById("goals").value.trim(),
        paymentPlan: document.getElementById("paymentPlan").value,
        parentGuardian: document.getElementById("parentGuardian").value.trim(),
        medicalConditions: document.getElementById("medicalConditions").value.trim(),
        communication: document.getElementById("communication").value,
        hearAboutUs: document.getElementById("hearAboutUs").value,
        lessonType: document.getElementById("lessonType").value,
        preferredTime: document.getElementById("preferredTime").value,
        startDate: document.getElementById("startDate").value,
        duration: document.getElementById("duration").value.trim(),
    };

    generateStudentId(formData.lastName, (studentId) => {
        const formRef = ref(database, 'registrations');
        const newFormRef = push(formRef);
        set(newFormRef, { ...formData, studentId }) // Store student ID along with form data
            .then(() => {
                alert(`Registration successful! Your Student ID is: ${studentId}. Generating your receipt. Please keep this receipt for your records.`);
                generatePDF(formData, studentId); // Generate PDF with submitted data
                resetForm();
                window.location.href = "payment.html"; // Redirect to payments page
            })
            .catch((error) => {
                alert("Sorry, there was an error. Please contact our representative for support! " + error);
            });
    });
}

// Function to generate Student ID based on last name and a unique number
function generateStudentId(lastName, callback) {
    const prefix = lastName ? lastName.substring(0, 3).toUpperCase() : "BDA";
    const randomNumber = Math.floor(100000 + Math.random() * 900000); // Generate a 6-digit random number
    const studentId = `${prefix}${randomNumber}`;

    // Check if the ID already exists in Firebase
    const idRef = ref(database, 'registrations');
    get(idRef).then((snapshot) => {
        const registrations = snapshot.val();
        const ids = registrations ? Object.values(registrations).map((reg) => reg.studentId) : [];
        if (ids.includes(studentId)) {
            // Regenerate if duplicate
            generateStudentId(lastName, callback);
        } else {
            callback(studentId); // Return the unique ID
        }
    });
}


function generatePDF(data, studentId) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Add Title
    doc.setFontSize(18);
    doc.text("Ben Dance Academy - Registration Receipt", 10, 10);

    // Add Student ID
    doc.setFontSize(12);
    doc.text(`Student ID: ${studentId}`, 10, 20);

    // Add Form Data
    let y = 30;
    for (const [key, value] of Object.entries(data)) {
        doc.text(`${key.replace(/([A-Z])/g, ' $1')}: ${value}`, 10, y);
        y += 10;
    }

    // Save the PDF with the Student ID in the filename
    doc.save(`Registration_${studentId}.pdf`);
}

function resetForm() {
    document.getElementById("signupForm").reset();
}

// Restrict Phone and Emergency Contact fields to only 10 digits
document.getElementById("phone").addEventListener("input", function (e) {
    e.target.value = e.target.value.replace(/[^0-9]/g, "").slice(0, 10);
});
document.getElementById("emergencyPhone").addEventListener("input", function (e) {
    e.target.value = e.target.value.replace(/[^0-9]/g, "").slice(0, 10);
});

// Restrict First Name and Last Name fields to only alphabets and spaces
document.getElementById("firstname").addEventListener("input", function (e) {
    e.target.value = e.target.value.replace(/[^a-zA-Z\s]/g, "");
});
document.getElementById("lastname").addEventListener("input", function (e) {
    e.target.value = e.target.value.replace(/[^a-zA-Z\s]/g, "");
});

// Set Date of Birth range
function setDobRange() {
    const dobInput = document.getElementById("dob");
    dobInput.setAttribute("min", "1995-01-01");
    dobInput.setAttribute("max", new Date().toISOString().split("T")[0]);
}

// Set Start Date to future dates only
function setStartDate() {
    const startDateInput = document.getElementById("startDate");
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    const minDate = `${yyyy}-${mm}-${dd}`;
    startDateInput.setAttribute("min", minDate);
}

// Initialize date restrictions on DOM load
document.addEventListener("DOMContentLoaded", () => {
    setDobRange();
    setStartDate();
});
